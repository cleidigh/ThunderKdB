pref("extensions.showInOut@ggbs.de.description", "chrome://showInOut/locale/showInOut.properties");
pref("extensions.showInOut.OutTextPrefix", "");
pref("extensions.showInOut.InTextPrefix", "");
pref("extensions.showInOut.Columns", "");
