Preferences.addAll([
//    { id: "extensions.showInOut.addaddr", type: "unichar" },
    { id: "extensions.showInOut.Columns", type: "unichar" },
    { id: "extensions.showInOut.InTextPrefix", type: "unichar" },
    { id: "extensions.showInOut.OutTextPrefix", type: "unichar" },

//demo:    { id: "extensions.showInOut.pref1", type: "bool" },
]);